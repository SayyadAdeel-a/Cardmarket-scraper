"""
worker.py — Continuous 24/7 background worker for Cardmarket scraper bot.
Automates watchlist cycles, proxy rotation, browser lifecycle recycling, SQLite storage, and price alerts.
"""

import argparse
import asyncio
import json
import logging
import os
import random
import signal
import sys
import time
from pathlib import Path
from typing import Optional
from urllib.request import Request, urlopen

import db
from models import Offer
from scraper import (
    PROXY_POOL,
    CloudflareBlocked,
    close_browser,
    scrape_card,
)
from settings import Card

LOGGER = logging.getLogger("worker")

DEFAULT_CYCLE_INTERVAL_S = 300  # 5 minutes resting between complete cycles
DEFAULT_CARD_DELAY_MIN_S = 10   # min seconds between cards
DEFAULT_CARD_DELAY_MAX_S = 20   # max seconds between cards
DEFAULT_RECYCLE_EVERY = 15      # recycle browser every 15 pages to keep memory lean
WATCHLIST_FILE = Path("watchlist.json")

_keep_running = True


def handle_shutdown(signum, frame):
    global _keep_running
    LOGGER.info("Shutdown signal received (signal %s). Finishing current task...", signum)
    _keep_running = False


def send_webhook(webhook_url: str, title: str, message: str) -> None:
    """Send alert notification to a Discord / Slack webhook."""
    if not webhook_url:
        return
    try:
        payload = json.dumps({"content": f"🚨 **{title}**\n{message}"}).encode("utf-8")
        req = Request(
            webhook_url,
            data=payload,
            headers={"Content-Type": "application/json", "User-Agent": "CardmarketBot/1.0"},
        )
        with urlopen(req, timeout=8) as res:
            pass
    except Exception as exc:
        LOGGER.warning("Failed to send webhook notification: %s", exc)


def load_watchlist(watchlist_path: Path = WATCHLIST_FILE) -> None:
    """Load and sync watchlist JSON into SQLite database."""
    if watchlist_path.exists():
        try:
            with open(watchlist_path, "r", encoding="utf-8") as f:
                items = json.load(f)
            if isinstance(items, list):
                db.sync_watchlist(items)
                LOGGER.info("Synced %d card(s) from %s into database.", len(items), watchlist_path)
        except Exception as exc:
            LOGGER.error("Error reading %s: %s", watchlist_path, exc)


async def run_worker(
    cycle_interval_s: int = DEFAULT_CYCLE_INTERVAL_S,
    recycle_every: int = DEFAULT_RECYCLE_EVERY,
    headless: bool = True,
    webhook_url: Optional[str] = None,
) -> None:
    global _keep_running

    db.init_db()
    load_watchlist()

    scrapes_since_recycle = 0
    proxy_index = 0
    cycle_count = 0

    LOGGER.info("Cardmarket 24/7 worker started. Press Ctrl+C to terminate cleanly.")

    while _keep_running:
        cycle_count += 1
        cycle_start = time.monotonic()
        load_watchlist()  # Re-sync in case user updated watchlist.json on the fly
        active_cards = db.get_active_cards()

        if not active_cards:
            LOGGER.warning("No active cards in watchlist. Waiting %ds before rechecking...", cycle_interval_s)
            for _ in range(cycle_interval_s):
                if not _keep_running:
                    break
                await asyncio.sleep(1)
            continue

        LOGGER.info(
            "=== Starting Cycle #%d (%d active target cards) ===",
            cycle_count,
            len(active_cards),
        )

        for card_data in active_cards:
            if not _keep_running:
                break

            card = Card(card_data["name"], card_data["url"])
            current_proxy = PROXY_POOL[proxy_index % len(PROXY_POOL)] if PROXY_POOL else None
            proxy_index += 1

            LOGGER.info("Processing target: %s (Alert: €%s)", card.name, card_data.get("max_price_alert"))

            try:
                offers = await scrape_card(
                    card,
                    max_attempts=2,
                    headless=headless,
                    proxy=current_proxy,
                )
                scrapes_since_recycle += 1

                # Record in database and evaluate alerts
                result = db.record_scrape_results(card.name, offers)
                LOGGER.info(
                    "[%s] Saved %d offers | Min: €%s | Avg: €%s",
                    card.name,
                    result["offers_count"],
                    result.get("min_price"),
                    result.get("avg_price"),
                )

                # Broadcast any alerts triggered
                for alert in result.get("alerts", []):
                    LOGGER.info("ALERT TRIGGERED: %s", alert["message"])
                    if webhook_url:
                        send_webhook(webhook_url, f"Deal Found: {card.name}", alert["message"])

            except CloudflareBlocked as exc:
                LOGGER.warning("Cloudflare challenge unresolved for %s: %s. Cooling down...", card.name, exc)
                await close_browser()
                scrapes_since_recycle = 0
                await asyncio.sleep(60.0)

            except Exception as exc:
                LOGGER.error("Error scraping %s: %s", card.name, exc)
                await close_browser()
                scrapes_since_recycle = 0
                await asyncio.sleep(15.0)

            # Prevent memory leaks: recycle the browser after N scrapes
            if scrapes_since_recycle >= recycle_every:
                LOGGER.info("Recycling browser process to keep memory usage minimal...")
                await close_browser()
                scrapes_since_recycle = 0

            # Pacing delay between consecutive cards
            delay = random.uniform(DEFAULT_CARD_DELAY_MIN_S, DEFAULT_CARD_DELAY_MAX_S)
            LOGGER.debug("Pausing %.1fs before next card...", delay)
            await asyncio.sleep(delay)

        # End of cycle: clean up browser to free resources while resting
        await close_browser()
        scrapes_since_recycle = 0

        cycle_duration = int(time.monotonic() - cycle_start)
        LOGGER.info(
            "=== Cycle #%d finished in %ds. Resting for %ds before next round ===",
            cycle_count,
            cycle_duration,
            cycle_interval_s,
        )

        # Resting interval with reactive shutdown check
        for _ in range(cycle_interval_s):
            if not _keep_running:
                break
            await asyncio.sleep(1)

    # Clean shutdown
    await close_browser()
    LOGGER.info("Worker stopped cleanly.")


if __name__ == "__main__":
    signal.signal(signal.SIGINT, handle_shutdown)
    signal.signal(signal.SIGTERM, handle_shutdown)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    parser = argparse.ArgumentParser(description="Cardmarket 24/7 Scraping Daemon")
    parser.add_argument(
        "--interval",
        type=int,
        default=DEFAULT_CYCLE_INTERVAL_S,
        help="Seconds to rest between full watchlist cycles (default 300)",
    )
    parser.add_argument(
        "--recycle-every",
        type=int,
        default=DEFAULT_RECYCLE_EVERY,
        help="Number of card scrapes before restarting browser process (default 15)",
    )
    parser.add_argument(
        "--headed",
        action="store_true",
        help="Run browser visibly (default is headless)",
    )
    parser.add_argument(
        "--webhook-url",
        default=os.getenv("CARDMARKET_WEBHOOK_URL"),
        help="Discord or Slack webhook URL for price alerts",
    )

    args = parser.parse_args()

    asyncio.run(
        run_worker(
            cycle_interval_s=args.interval,
            recycle_every=args.recycle_every,
            headless=not args.headed,
            webhook_url=args.webhook_url,
        )
    )

