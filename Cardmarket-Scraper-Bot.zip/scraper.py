"""
scraper.py — Cardmarket scraper powered by CloakBrowser stealth Chromium.
Replaces Hyperbrowser cloud sessions and raw CDP websockets with source-level stealth browser automation.
"""

import asyncio
import csv
import json
import logging
import os
import random
import time
from pathlib import Path
from typing import Optional

from cloakbrowser import launch_persistent_context_async

from models import Offer
from parser import parse_offers
from settings import Card

LOGGER = logging.getLogger(__name__)

PROFILE_DIR = str(Path.home() / ".config" / "cardmarket-bot-profile")
_NAV_GAP_MIN_S = 3.0    # polite delay between page loads
_NAV_GAP_MAX_S = 7.0
_CHALLENGE_WAIT_S = 45.0  # max time to let Cloudflare solve
_CFM_MAX_SOLVE_ATTEMPTS = 3
_COOLDOWN_S = 90.0

_CHALLENGE_MARKERS = (
    "just a moment",
    "cf-chl",
    "cf-challenge",
    "cf-turnstile",
    "challenge-platform",
    "attention required",
    "verify you are human",
    "hcaptcha",
    "cf-chl-turnstile",
)
_LISTING_MARKERS = ("listingtable", "article-row")

# "Show more results" handling
_MAX_SHOW_MORE_CLICKS = 150
_SHOW_MORE_GROW_WAIT_S = 15.0
_SHOW_MORE_STALL_RETRIES = 3

_JS_ROW_COUNT = "document.querySelectorAll('.article-row').length"

# Returns "none" when button is gone/hidden, "clicked" after a click
_JS_CLICK_SHOW_MORE = """(() => {
    const visible = el => el && el.offsetParent !== null
        && !el.disabled && !el.classList.contains('d-none');
    let btn = document.querySelector('#loadMoreButton');
    if (!visible(btn)) {
        btn = Array.from(document.querySelectorAll('button, a')).find(
            el => visible(el) && /show more results/i.test(el.textContent || ''));
    }
    if (!btn) return "none";
    btn.scrollIntoView({block: "center"});
    btn.click();
    return "clicked";
})()"""

def _load_proxy_pool() -> list[str]:
    proxy_file = Path("proxies.txt")
    if proxy_file.exists():
        try:
            lines = [l.strip() for l in proxy_file.read_text(encoding="utf-8").splitlines()]
            active = [l for l in lines if l and not l.startswith("#")]
            if active:
                return active
        except Exception as exc:
            LOGGER.warning("Could not read proxies.txt: %s", exc)
    return [
        "84.75.95.111:22864:pefrewycbqtxb1r:ecvimWLZHmR6",
        "84.75.95.112:42669:pefrewycbqtxb1r:ecvimWLZHmR6",
    ]


PROXY_POOL = _load_proxy_pool()

_browser_context = None
_active_page = None
_lock: Optional[asyncio.Lock] = None
_last_nav = 0.0
_cooldown_until = 0.0
_current_url = ""


class CloudflareBlocked(Exception):
    """A Cloudflare interstitial is still showing after the wait window."""


def _format_proxy(proxy_str: str) -> str:
    """Normalize proxy string into standard http://user:pass@host:port format."""
    if not proxy_str:
        return ""
    if proxy_str.startswith(("http://", "https://", "socks5://")):
        return proxy_str
    parts = proxy_str.split(":")
    if len(parts) == 4:
        ip, port, user, password = parts
        return f"http://{user}:{password}@{ip}:{port}"
    if len(parts) == 2:
        ip, port = parts
        return f"http://{ip}:{port}"
    return proxy_str


def _get_lock() -> asyncio.Lock:
    global _lock
    if _lock is None:
        _lock = asyncio.Lock()
    return _lock


def _is_challenge(html: str) -> bool:
    low = (html or "").lower()
    if any(m in low for m in _LISTING_MARKERS):
        return False
    return any(m in low for m in _CHALLENGE_MARKERS)


def _has_listings(html: str) -> bool:
    low = (html or "").lower()
    return any(m in low for m in _LISTING_MARKERS)


async def _ensure_browser(headless: bool = True, proxy: Optional[str] = None):
    """Launch or reuse a local CloakBrowser persistent context with source-level stealth."""
    global _browser_context, _active_page
    async with _get_lock():
        if _browser_context is None:
            selected_proxy = proxy or (random.choice(PROXY_POOL) if PROXY_POOL else None)
            proxy_url = _format_proxy(selected_proxy) if selected_proxy else None

            LOGGER.info(
                "Launching CloakBrowser (headless=%s, proxy=%s, profile=%s)...",
                headless,
                bool(proxy_url),
                PROFILE_DIR,
            )
            _browser_context = await launch_persistent_context_async(
                user_data_dir=PROFILE_DIR,
                headless=headless,
                proxy=proxy_url,
                geoip=bool(proxy_url),
                humanize=True,
            )
            if _browser_context.pages:
                _active_page = _browser_context.pages[0]
            else:
                _active_page = await _browser_context.new_page()

            LOGGER.info("CloakBrowser instance ready.")
        return _active_page


async def _get_tab(headless: bool = True):
    return await _ensure_browser(headless=headless)


async def _navigate(page, url: str) -> None:
    global _last_nav, _current_url
    gap = random.uniform(_NAV_GAP_MIN_S, _NAV_GAP_MAX_S)
    wait = gap - (time.monotonic() - _last_nav)
    if wait > 0:
        await asyncio.sleep(wait)

    LOGGER.info("Navigating to: %s", url)
    await page.goto(url, wait_until="domcontentloaded", timeout=45000)
    _current_url = page.url
    _last_nav = time.monotonic()


async def _wait_out_challenge(page, max_wait_s: float = _CHALLENGE_WAIT_S) -> str:
    """Wait for Cloudflare to clear automatically or via fallback Turnstile interaction."""
    deadline = time.monotonic() + max_wait_s
    LOGGER.info("Cloudflare challenge encountered; waiting for resolution...")

    while time.monotonic() < deadline:
        await asyncio.sleep(1.5)
        title = await page.title()
        html = await page.content()

        if not _is_challenge(html):
            LOGGER.info("Cloudflare challenge cleared (Title: '%s').", title)
            return html

        # Fallback: check if interactive Turnstile iframe checkbox is rendered
        try:
            turnstile_iframe = page.frame_locator('iframe[src*="challenges.cloudflare.com"], iframe[src*="turnstile"]')
            checkbox = turnstile_iframe.locator('input[type="checkbox"], #challenge-stage, .cb-lb')
            if await checkbox.count() > 0 and await checkbox.first.is_visible():
                LOGGER.info("Interactive Turnstile checkbox detected; clicking...")
                await checkbox.first.click()
                await asyncio.sleep(2.0)
        except Exception:
            pass

    return await page.content()


async def _row_count(page) -> int:
    try:
        return int(await page.evaluate(_JS_ROW_COUNT) or 0)
    except Exception:
        return 0


async def _expand_all(page, card: Card) -> None:
    """Click 'Show more results' until all listings are loaded."""
    stalls = 0
    for click_no in range(1, _MAX_SHOW_MORE_CLICKS + 1):
        before = await _row_count(page)
        try:
            state = await page.evaluate(_JS_CLICK_SHOW_MORE)
        except Exception as exc:
            LOGGER.warning("Show-more check failed for %s: %s", card.name, exc)
            return

        if state != "clicked":
            LOGGER.info("%s: fully expanded (%d rows, %d clicks).", card.name, before, click_no - 1)
            return

        # Wait for new rows to appear
        deadline = time.monotonic() + _SHOW_MORE_GROW_WAIT_S
        grew = False
        while time.monotonic() < deadline:
            await asyncio.sleep(0.8)
            if await _row_count(page) > before:
                grew = True
                break

        if grew:
            stalls = 0
        else:
            stalls += 1
            if stalls >= _SHOW_MORE_STALL_RETRIES:
                LOGGER.warning("%s: show-more stalled at %d rows; using what loaded.", card.name, before)
                return

        await asyncio.sleep(random.uniform(0.8, 2.0))
    LOGGER.warning("%s: hit show-more click cap.", card.name)


async def _wait_for_listings(page, max_wait_s: float = 30.0) -> str:
    deadline = time.monotonic() + max_wait_s
    while time.monotonic() < deadline:
        html = await page.content()
        if _has_listings(html) and not _is_challenge(html):
            return html
        await asyncio.sleep(1.0)
    return await page.content()


async def scrape_card(
    card: Card,
    max_attempts: int = 2,
    headless: bool = True,
    proxy: Optional[str] = None,
) -> list[Offer]:
    """Scrape listings for a given card URL with automatic challenge evasion."""
    global _cooldown_until, _current_url

    if time.monotonic() < _cooldown_until:
        remaining = int(_cooldown_until - time.monotonic())
        LOGGER.info("System recovery buffer active (%ds remaining). Proceeding...", remaining)

    last_err: Optional[Exception] = None
    for attempt in range(1, max_attempts + 1):
        try:
            page = await _ensure_browser(headless=headless, proxy=proxy)

            if _current_url.rstrip("/") != card.url.rstrip("/"):
                await _navigate(page, card.url)

            html = await page.content()
            if _is_challenge(html):
                html = await _wait_out_challenge(page)
                if _is_challenge(html):
                    _cooldown_until = time.monotonic() + _COOLDOWN_S
                    raise CloudflareBlocked(f"challenge unresolved ({card.name})")

            html = await _wait_for_listings(page, max_wait_s=30.0)
            if _is_challenge(html):
                html = await _wait_out_challenge(page)
                if _is_challenge(html):
                    _cooldown_until = time.monotonic() + _COOLDOWN_S
                    raise CloudflareBlocked(f"challenge unresolved ({card.name})")

            if not _has_listings(html):
                LOGGER.warning("No listings visible for %s — reloading page.", card.name)
                await _navigate(page, card.url)
                html = await _wait_for_listings(page, max_wait_s=20.0)
                if not _has_listings(html):
                    LOGGER.warning("Listings never appeared for %s; skipping cycle.", card.name)
                    return []

            await _expand_all(page, card)
            html = await page.content()
            offers = parse_offers(html, card)
            LOGGER.info("Parsed %d offer(s) for %s.", len(offers), card.name)
            return offers
        except CloudflareBlocked:
            await close_browser()
            raise
        except Exception as exc:
            last_err = exc
            LOGGER.warning("Scrape attempt %d failed for %s: %s", attempt, card.name, exc)
            await close_browser()
            await asyncio.sleep(1.5)

    raise ConnectionError(f"scrape_card failed for {card.name}: {last_err}")


def save_offers(offers: list[Offer], file_path: str | Path) -> Path:
    """Save parsed offers to a JSON or CSV file."""
    path = Path(file_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    data = [o.to_dict() for o in offers]

    if path.suffix.lower() == ".csv":
        if data:
            fieldnames = list(data[0].keys())
            with open(path, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(data)
        else:
            with open(path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["product_id", "title", "price", "currency", "condition", "seller"])
    else:
        # Default to JSON
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    LOGGER.info("Saved %d offer(s) to %s", len(offers), path)
    return path


async def close_browser() -> None:
    """Close the active CloakBrowser context cleanly."""
    global _browser_context, _active_page, _current_url

    if _browser_context is not None:
        try:
            await _browser_context.close()
        except Exception:
            pass
    _browser_context = None
    _active_page = None
    _current_url = ""
    LOGGER.info("CloakBrowser context closed cleanly.")


if __name__ == "__main__":
    import argparse

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    _parser = argparse.ArgumentParser(description="Cardmarket scraper bot")
    _parser.add_argument("--name", default="Card")
    _parser.add_argument("--url", required=True, help="Cardmarket listing URL to scrape")
    _parser.add_argument("--headed", action="store_true", help="Run browser in visible headed mode")
    _parser.add_argument("--output", help="File path to save parsed offers (e.g., offers.json or offers.csv)")
    _args = _parser.parse_args()

    async def _run() -> None:
        card = Card(_args.name, _args.url)
        try:
            offers = await scrape_card(card, headless=not _args.headed)
            print(f"Found {len(offers)} offer(s) for {card.name}.")
            if offers:
                safe_name = "".join(c if c.isalnum() or c in ("-", "_") else "_" for c in _args.name).strip("_").lower()
                out_path = _args.output or f"output/{safe_name}_offers.json"
                saved_to = save_offers(offers, out_path)
                print(f"Successfully saved {len(offers)} offer(s) to: {saved_to}")
        except Exception as exc:
            print(f"Scrape failed for {card.name}: {exc}")
        finally:
            await close_browser()

    asyncio.run(_run())
