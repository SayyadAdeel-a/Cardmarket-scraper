"""Offer parsing implementation for Cardmarket listing pages."""

import logging
import re
from typing import List, Optional

from bs4 import BeautifulSoup
from models import Offer

LOGGER = logging.getLogger(__name__)


def _parse_price(price_text: str) -> tuple[Optional[float], str]:
    """Parse European price string like '4,00 €' or '1.250,50 €' into float and currency."""
    if not price_text:
        return None, "EUR"

    currency = "EUR"
    if "€" in price_text or "EUR" in price_text:
        currency = "EUR"
    elif "$" in price_text or "USD" in price_text:
        currency = "USD"
    elif "£" in price_text or "GBP" in price_text:
        currency = "GBP"

    # Remove non-numeric characters except commas and dots
    cleaned = re.sub(r"[^\d,\.]", "", price_text).strip()
    if not cleaned:
        return None, currency

    # European format: 1.234,56 -> remove '.' thousands separator, replace ',' decimal with '.'
    if "," in cleaned:
        cleaned = cleaned.replace(".", "").replace(",", ".")
    try:
        return float(cleaned), currency
    except ValueError:
        return None, currency


def parse_offers(html: str, card=None) -> List[Offer]:
    """Parse raw Cardmarket listing HTML into a list of Offer objects."""
    if not html:
        return []

    soup = BeautifulSoup(html, "html.parser")
    rows = soup.select(".article-row")
    if not rows:
        return []

    card_name = getattr(card, "name", "") if card else ""
    if not card_name:
        h1 = soup.select_one("h1")
        if h1:
            card_name = h1.get_text(strip=True)

    offers: List[Offer] = []

    for row in rows:
        try:
            # 1. Product ID
            raw_id = row.get("id", "")
            product_id = raw_id.replace("articleRow", "") if raw_id else None

            # 2. Seller Name
            seller_el = row.select_one(".col-seller a, .seller-name a")
            seller = seller_el.get_text(strip=True) if seller_el else None

            # 3. Seller Location / Country
            loc_el = (
                row.select_one('.col-seller [aria-label*="location"]')
                or row.select_one('.col-seller [data-bs-original-title*="location"]')
                or row.select_one('.seller-name [aria-label*="location"]')
                or row.select_one('.seller-name [data-bs-original-title*="location"]')
            )
            seller_country = None
            if loc_el:
                raw_loc = loc_el.get("aria-label") or loc_el.get("data-bs-original-title") or ""
                m = re.search(r"location:\s*([^\"\|]+)", raw_loc, re.IGNORECASE)
                seller_country = m.group(1).strip() if m else raw_loc.strip()

            # 4. Condition (MT, NM, EX, GD, LP, PL, PO)
            cond_el = row.select_one(".article-condition")
            condition = cond_el.get_text(strip=True) if cond_el else None

            # 5. Language
            lang_el = row.select_one('.product-attributes span.icon[aria-label], .product-attributes span.icon[data-bs-original-title]')
            language = None
            if lang_el:
                language = lang_el.get("aria-label") or lang_el.get("data-bs-original-title")

            # 6. Price & Currency
            price_el = (
                row.select_one(".price-container .color-primary")
                or row.select_one(".col-offer .color-primary")
                or row.select_one(".color-primary")
            )
            price, currency = (None, "EUR")
            if price_el:
                price, currency = _parse_price(price_el.get_text(strip=True))

            # 7. Item count / Available quantity
            amount_el = row.select_one(".amount-container .item-count, .item-count")
            item_count = 1
            if amount_el:
                txt = amount_el.get_text(strip=True)
                if txt.isdigit():
                    item_count = int(txt)

            # 8. Extra Card Attributes
            is_foil = bool(row.select_one('.fonticon-foil, [data-bs-original-title*="Foil"], [aria-label*="Foil"]'))
            is_signed = bool(row.select_one('.fonticon-signed, [data-bs-original-title*="Signed"], [aria-label*="Signed"]'))
            is_first_ed = bool(row.select_one('.fonticon-first-edition, [data-bs-original-title*="First Edition"], [aria-label*="First Edition"]'))
            is_altered = bool(row.select_one('.fonticon-altered, [data-bs-original-title*="Altered"], [aria-label*="Altered"]'))

            # 9. Comments / Notes
            comment_el = row.select_one(".product-comments, [data-bs-original-title*='Comment']")
            comments = comment_el.get_text(strip=True) if comment_el else None

            offer = Offer(
                product_id=product_id,
                title=card_name,
                price=price,
                currency=currency,
                condition=condition,
                seller=seller,
                seller_country=seller_country,
                item_count=item_count,
                language=language,
                is_foil=is_foil,
                is_signed=is_signed,
                is_first_ed=is_first_ed,
                is_altered=is_altered,
                comments=comments,
            )
            offers.append(offer)
        except Exception as exc:
            LOGGER.debug("Error parsing article row: %s", exc)
            continue

    return offers
