@echo off
cd /d "%~dp0"
title Cardmarket 24/7 Scraper Bot
echo Starting Cardmarket 24/7 worker daemon...
python worker.py --interval 300 --recycle-every 15
pause

