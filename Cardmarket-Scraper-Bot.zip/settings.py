"""Runtime settings / card definitions for the scraper bot."""


class Card:
    def __init__(self, name: str = "", url: str = "", category: str = ""):
        self.name = name
        self.url = url
        self.category = category
