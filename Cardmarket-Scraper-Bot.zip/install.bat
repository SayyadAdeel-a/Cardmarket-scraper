@echo off
cd /d "%~dp0"
title Cardmarket Scraper - Setup
echo ========================================================
echo       Cardmarket 24/7 Scraper Bot - Initial Setup
echo ========================================================
echo.
echo [1/2] Installing required Python dependencies...
python -m pip install -r requirements.txt
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ERROR: Failed to install Python dependencies.
    echo Please make sure Python 3.10+ is installed and added to PATH.
    pause
    exit /b %ERRORLEVEL%
)

echo.
echo [2/2] Downloading stealth Chromium browser engine...
python -m cloakbrowser install
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo ERROR: Failed to download stealth browser binary.
    pause
    exit /b %ERRORLEVEL%
)

echo.
echo ========================================================
echo Setup completed successfully!
echo You can now edit watchlist.json and run 'run_worker.bat'
echo ========================================================
echo.
pause
