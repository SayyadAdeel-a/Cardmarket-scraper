"""Data models for the Cardmarket scraper bot."""

from dataclasses import asdict, dataclass
from typing import Optional


@dataclass
class Offer:
    product_id: Optional[str] = None
    title: str = ""
    price: Optional[float] = None
    currency: str = "EUR"
    condition: Optional[str] = None
    seller: Optional[str] = None
    seller_country: Optional[str] = None
    item_count: int = 1
    language: Optional[str] = None
    is_foil: bool = False
    is_signed: bool = False
    is_first_ed: bool = False
    is_altered: bool = False
    comments: Optional[str] = None

    def to_dict(self) -> dict:
        return asdict(self)
