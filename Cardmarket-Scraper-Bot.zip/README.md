# Cardmarket 24/7 Scraper & Price Monitor Bot

A high-performance automated scraping and price monitoring bot for **Cardmarket** powered by source-level stealth browser automation (CloakBrowser). Automatically bypasses Cloudflare bot protection and runs 24/7.

---

## 🚀 Quick Start (Client Setup)

### 1. Requirements
- **Windows 10 / 11**
- **Python 3.10 or higher** installed from [python.org](https://www.python.org/).
  - *Important:* Make sure to check **"Add python.exe to PATH"** during installation.

### 2. One-Time Setup
Double-click:
```text
install.bat
```
This automatically installs the required Python packages and downloads the stealth browser binary.

### 3. Configure Your Cards
Open `watchlist.json` in Notepad or any text editor and specify the cards you want to track:
```json
[
  {
    "name": "Radiant Charizard",
    "url": "https://www.cardmarket.com/en/Pokemon/Products/Singles/Crown-Zenith/Radiant-Charizard-CRZ020",
    "max_price_alert": 5.50,
    "is_active": true
  }
]
```
- `name`: Friendly name for the card.
- `url`: Full Cardmarket listing URL.
- `max_price_alert`: (Optional) Price threshold. Any offer equal to or below this price triggers an alert.
- `is_active`: Set to `true` to track, or `false` to temporarily pause.

### 4. (Optional) Configure Proxies
Open `proxies.txt` to add or update your proxies (one per line):
```text
ip:port:username:password
```

### 5. Launch the Bot
Double-click:
```text
run_worker.bat
```
The bot will now continuously cycle through your watchlist, monitor prices, record offers, and alert you on deals!

---

## 📊 Where is the Data Saved?

All collected data is stored in a local SQLite database: **`cardmarket.db`**.

You can view and query this database using free tools like [DB Browser for SQLite](https://sqlitebrowser.org/):
- **`offers`**: Contains every individual listing (product ID, price, condition, seller, country, language, foil/signed/first-ed flags, comments, timestamps).
- **`price_history`**: Historical snapshots (min price, average price, total offer count) recorded on every cycle.
- **`alerts`**: Log of all detected deals below your `max_price_alert` thresholds.

---

## 🔔 Discord / Slack Webhook Alerts

To receive instant notifications directly to your Discord or Slack channel whenever a deal is found:
1. Open `run_worker.bat` in Notepad.
2. Add `--webhook-url "YOUR_WEBHOOK_URL"`:
   ```cmd
   python worker.py --interval 300 --recycle-every 15 --webhook-url "https://discord.com/api/webhooks/..."
   ```

---

## ⚡ Run Automatically on Windows Boot (24/7)

To ensure the bot starts automatically even if your computer restarts:
1. Press `Win + R`, type `taskschd.msc`, and press **Enter** to open **Task Scheduler**.
2. Click **Create Basic Task...** on the right.
3. Name: `Cardmarket Scraper Bot`.
4. Trigger: Select **When I log on** or **When the computer starts**.
5. Action: Select **Start a program**.
6. Program/script: Browse to and select `run_worker.bat`.
7. Finish and check **Run with highest privileges**.

---

## 🛠 Manual Commands (For Advanced Users)

- **Run single scrape and export to JSON/CSV**:
  ```powershell
  python scraper.py --name "Radiant Charizard" --url "https://..." --output "offers.json"
  python scraper.py --name "Radiant Charizard" --url "https://..." --output "offers.csv"
  ```
- **Run worker with custom intervals**:
  ```powershell
  python worker.py --interval 180 --recycle-every 20
  ```
