"""
db.py — SQLite database management for Cardmarket continuous scraper.
Handles cards, current offers, price history, and price alert logs.
"""

import logging
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from models import Offer

LOGGER = logging.getLogger(__name__)

DB_PATH = Path("cardmarket.db")


def get_connection(db_path: Path = DB_PATH) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(db_path: Path = DB_PATH) -> None:
    """Initialize database tables and indexes."""
    with get_connection(db_path) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS cards (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                url TEXT NOT NULL,
                max_price_alert REAL,
                is_active INTEGER DEFAULT 1,
                last_scraped_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS offers (
                product_id TEXT PRIMARY KEY,
                card_name TEXT NOT NULL,
                price REAL NOT NULL,
                currency TEXT DEFAULT 'EUR',
                condition TEXT,
                seller TEXT,
                seller_country TEXT,
                item_count INTEGER DEFAULT 1,
                language TEXT,
                is_foil INTEGER DEFAULT 0,
                is_signed INTEGER DEFAULT 0,
                is_first_ed INTEGER DEFAULT 0,
                is_altered INTEGER DEFAULT 0,
                comments TEXT,
                first_seen_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_seen_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_active INTEGER DEFAULT 1,
                FOREIGN KEY (card_name) REFERENCES cards (name)
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS price_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                card_name TEXT NOT NULL,
                min_price REAL,
                avg_price REAL,
                total_offers INTEGER,
                scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (card_name) REFERENCES cards (name)
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                card_name TEXT NOT NULL,
                product_id TEXT,
                price REAL,
                alert_type TEXT,
                message TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Indexes for fast querying
        conn.execute("CREATE INDEX IF NOT EXISTS idx_offers_card_name ON offers (card_name);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_offers_active ON offers (is_active);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_history_card ON price_history (card_name);")
        conn.commit()
    LOGGER.info("Database initialized at %s", db_path.resolve())


def sync_watchlist(watchlist: list[dict], db_path: Path = DB_PATH) -> None:
    """Sync watchlist JSON configuration into the database."""
    with get_connection(db_path) as conn:
        for item in watchlist:
            name = item.get("name")
            url = item.get("url")
            max_alert = item.get("max_price_alert")
            is_active = 1 if item.get("is_active", True) else 0

            if not name or not url:
                continue

            conn.execute("""
                INSERT INTO cards (name, url, max_price_alert, is_active)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(name) DO UPDATE SET
                    url = excluded.url,
                    max_price_alert = COALESCE(excluded.max_price_alert, cards.max_price_alert),
                    is_active = excluded.is_active
            """, (name, url, max_alert, is_active))
        conn.commit()


def get_active_cards(db_path: Path = DB_PATH) -> list[dict]:
    """Retrieve all active cards queued for scraping."""
    with get_connection(db_path) as conn:
        cursor = conn.execute("SELECT id, name, url, max_price_alert FROM cards WHERE is_active = 1")
        return [dict(row) for row in cursor.fetchall()]


def record_scrape_results(card_name: str, offers: List[Offer], db_path: Path = DB_PATH) -> dict:
    """
    Save offers to database, update active statuses, log price history, and return any detected alerts.
    """
    now_str = datetime.now().isoformat()
    alerts: list[dict] = []

    with get_connection(db_path) as conn:
        # 1. Update last scraped timestamp on card
        card_row = conn.execute("SELECT max_price_alert FROM cards WHERE name = ?", (card_name,)).fetchone()
        max_price_alert = card_row["max_price_alert"] if card_row else None
        conn.execute("UPDATE cards SET last_scraped_at = ? WHERE name = ?", (now_str, card_name))

        if not offers:
            conn.commit()
            return {"offers_count": 0, "alerts": []}

        # 2. Mark previous offers for this card as inactive temporarily
        conn.execute("UPDATE offers SET is_active = 0 WHERE card_name = ?", (card_name,))

        valid_prices = []
        for o in offers:
            if not o.product_id or o.price is None:
                continue

            valid_prices.append(o.price)

            # Insert or update offer
            conn.execute("""
                INSERT INTO offers (
                    product_id, card_name, price, currency, condition,
                    seller, seller_country, item_count, language,
                    is_foil, is_signed, is_first_ed, is_altered, comments,
                    first_seen_at, last_seen_at, is_active
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
                ON CONFLICT(product_id) DO UPDATE SET
                    price = excluded.price,
                    condition = excluded.condition,
                    item_count = excluded.item_count,
                    comments = excluded.comments,
                    last_seen_at = excluded.last_seen_at,
                    is_active = 1
            """, (
                o.product_id, card_name, o.price, o.currency, o.condition,
                o.seller, o.seller_country, o.item_count, o.language,
                1 if o.is_foil else 0, 1 if o.is_signed else 0,
                1 if o.is_first_ed else 0, 1 if o.is_altered else 0,
                o.comments, now_str, now_str
            ))

            # 3. Check for threshold alert
            if max_price_alert is not None and o.price <= max_price_alert:
                alert_msg = f"Offer for '{card_name}' by {o.seller} is €{o.price:.2f} (<= alert threshold €{max_price_alert:.2f})!"
                alerts.append({
                    "card_name": card_name,
                    "product_id": o.product_id,
                    "price": o.price,
                    "seller": o.seller,
                    "message": alert_msg,
                })
                conn.execute("""
                    INSERT INTO alerts (card_name, product_id, price, alert_type, message)
                    VALUES (?, ?, ?, 'BELOW_THRESHOLD', ?)
                """, (card_name, o.product_id, o.price, alert_msg))

        # 4. Record summary snapshot in price_history
        if valid_prices:
            min_price = min(valid_prices)
            avg_price = sum(valid_prices) / len(valid_prices)
            conn.execute("""
                INSERT INTO price_history (card_name, min_price, avg_price, total_offers, scraped_at)
                VALUES (?, ?, ?, ?, ?)
            """, (card_name, round(min_price, 2), round(avg_price, 2), len(valid_prices), now_str))

        conn.commit()

    return {
        "offers_count": len(offers),
        "min_price": min(valid_prices) if valid_prices else None,
        "avg_price": round(sum(valid_prices) / len(valid_prices), 2) if valid_prices else None,
        "alerts": alerts,
    }

